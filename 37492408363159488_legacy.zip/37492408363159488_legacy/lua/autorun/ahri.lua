player_manager.AddValidModel( "Ahri, The Nine-Tailed Fox","models/player_ahri_tails.mdl" )
list.Set( "PlayerOptionsModel",  "Ahri","models/player_ahri_tails.mdl" )
player_manager.AddValidHands( "Ahri, The Nine-Tailed Fox", "models/player_ahri_arms.mdl", 0, "00000000" )